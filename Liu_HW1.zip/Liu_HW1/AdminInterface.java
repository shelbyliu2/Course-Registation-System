
public interface AdminInterface {
	
	//Course management
	static void createNew() {}
	
	static void delete() {}
	
	static void edit() {}
	
	static void displayCourseInfo() {}
	
	static void registerStudent() {}
	
	
	
	// Reports
	
	static void viewAll() {}
	
	static void viewFull() {}
	
	static void writeToFile() {}
	
	static void viewStudentsInCourse() {}
	
	static void studentRegisteredCourses() {}
	
	static void sortByRegistration() {}
	
	static void exit() {}
}
