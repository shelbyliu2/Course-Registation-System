
public interface StudentInterface {

	static void viewAll() {}
	
	static void viewNotFull() {}
	
	static void register() {}
	
	static void withdraw() {}
	
	static void viewEnrolled() {}
	
	static void exit() {}
	
	
}
